import { useState, useCallback, useRef, useEffect } from "react";
import * as XLSX from "xlsx";

const CATEGORIES = [
  { id: "food", label: "🍔 אוכל ומסעדות", color: "#FF6B6B" },
  { id: "transport", label: "🚗 תחבורה", color: "#4ECDC4" },
  { id: "shopping", label: "🛍️ קניות", color: "#FFE66D" },
  { id: "health", label: "💊 בריאות", color: "#A8E6CF" },
  { id: "entertainment", label: "🎬 בילויים", color: "#DDA0DD" },
  { id: "bills", label: "📄 חשבונות", color: "#87CEEB" },
  { id: "education", label: "📚 חינוך", color: "#F0A500" },
  { id: "other", label: "📦 אחר", color: "#C0C0C0" },
];

const MONTHS = ["ינואר","פברואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"];
const currentMonth = new Date().getMonth();
const currentYear = new Date().getFullYear();

function formatILS(n) {
  return new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS", maximumFractionDigits: 0 }).format(n);
}

function guessCategory(description = "") {
  const d = description.toLowerCase();
  if (/מסעד|אוכל|קפה|סופר|שופרסל|רמי לוי|מקדונלד|בורגר|פיצה/.test(d)) return "food";
  if (/דלק|חניה|אוטובוס|רכבת|מונית|אובר|גט/.test(d)) return "transport";
  if (/זארה|h&m|שופינג|קניון|אמזון|אלי/.test(d)) return "shopping";
  if (/בית חולים|רופא|תרופה|קופת חולים|מאוחדת|מכבי/.test(d)) return "health";
  if (/סרט|קולנוע|נטפליקס|ספוטיפיי|גיימינג|בילוי/.test(d)) return "entertainment";
  if (/חשמל|מים|גז|טלפון|אינטרנט|ביטוח|שכירות/.test(d)) return "bills";
  if (/קורס|לימוד|ספר|אוניברסיטה/.test(d)) return "education";
  return "other";
}

function loadFromStorage() {
  try {
    const saved = localStorage.getItem("budget-app-data");
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  const d = {};
  for (let m = 0; m < 12; m++) {
    d[`${currentYear}-${m}`] = { salary: 0, extra: 0, savings: 0, transactions: [] };
  }
  return d;
}

export default function BudgetApp() {
  const [view, setView] = useState("dashboard");
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [monthlyData, setMonthlyData] = useState(loadFromStorage);
  const [editIncome, setEditIncome] = useState(false);
  const [incomeForm, setIncomeForm] = useState({ salary: "", extra: "", savings: "" });
  const [dragActive, setDragActive] = useState(false);
  const [uploadMsg, setUploadMsg] = useState("");
  const fileRef = useRef();

  // Save to localStorage on every change
  useEffect(() => {
    try { localStorage.setItem("budget-app-data", JSON.stringify(monthlyData)); } catch (e) {}
  }, [monthlyData]);

  const key = `${selectedYear}-${selectedMonth}`;
  const data = monthlyData[key] || { salary: 0, extra: 0, savings: 0, transactions: [] };
  const totalIncome = data.salary + data.extra;
  const totalExpenses = data.transactions.reduce((s, t) => s + Math.abs(t.amount), 0);
  const freeCash = totalIncome - totalExpenses - data.savings;

  const catTotals = CATEGORIES.map((cat) => ({
    ...cat,
    total: data.transactions.filter((t) => t.category === cat.id).reduce((s, t) => s + Math.abs(t.amount), 0),
  })).filter((c) => c.total > 0);

  const updateMonth = (patch) => {
    setMonthlyData((prev) => ({
      ...prev,
      [key]: { ...(prev[key] || { salary: 0, extra: 0, savings: 0, transactions: [] }), ...patch },
    }));
  };

  const saveIncome = () => {
    updateMonth({
      salary: parseFloat(incomeForm.salary) || data.salary,
      extra: parseFloat(incomeForm.extra) || data.extra,
      savings: parseFloat(incomeForm.savings) || data.savings,
    });
    setEditIncome(false);
  };

  const openIncomeEdit = () => {
    setIncomeForm({ salary: data.salary || "", extra: data.extra || "", savings: data.savings || "" });
    setEditIncome(true);
  };

  const handleFile = useCallback(async (file) => {
    if (!file) return;
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf);
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
      const txns = [];
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row.length < 2) continue;
        const desc = String(row[1] || row[0] || "");
        const amountRaw = row[2] || row[3] || row[1];
        const amount = parseFloat(String(amountRaw).replace(/[^\d.-]/g, ""));
        if (isNaN(amount) || amount === 0) continue;
        txns.push({ id: Date.now() + i, date: row[0] || "", description: desc, amount: -Math.abs(amount), category: guessCategory(desc) });
      }
      updateMonth({ transactions: [...data.transactions, ...txns] });
      setUploadMsg(`✅ יובאו ${txns.length} עסקאות בהצלחה!`);
      setTimeout(() => setUploadMsg(""), 4000);
    } catch (e) {
      setUploadMsg("❌ שגיאה בקריאת הקובץ. ודאי שזה קובץ Excel תקין.");
      setTimeout(() => setUploadMsg(""), 4000);
    }
  }, [data.transactions, key]);

  const updateTxnCategory = (id, cat) => updateMonth({ transactions: data.transactions.map((t) => (t.id === id ? { ...t, category: cat } : t)) });
  const deleteTxn = (id) => updateMonth({ transactions: data.transactions.filter((t) => t.id !== id) });
  const maxCat = Math.max(...catTotals.map((c) => c.total), 1);

  const historyMonths = [];
  for (let i = 11; i >= 0; i--) {
    let m = currentMonth - i, y = currentYear;
    if (m < 0) { m += 12; y -= 1; }
    const k = `${y}-${m}`;
    const d = monthlyData[k] || { salary: 0, extra: 0, savings: 0, transactions: [] };
    const income = d.salary + d.extra;
    const expenses = d.transactions.reduce((s, t) => s + Math.abs(t.amount), 0);
    historyMonths.push({ month: m, year: y, key: k, label: `${MONTHS[m]} ${y}`, income, expenses, savings: d.savings, free: income - expenses - d.savings, txCount: d.transactions.length });
  }
  const historyWithData = historyMonths.filter(h => h.income > 0 || h.txCount > 0);
  const maxExpHistory = Math.max(...historyMonths.map(h => h.expenses), 1);

  return (
    <div dir="rtl" style={{ fontFamily: "'Assistant', 'Heebo', sans-serif", minHeight: "100vh", background: "#0F0F14", color: "#E8E6E1" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Assistant:wght@300;400;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #1A1A24; }
        ::-webkit-scrollbar-thumb { background: #3A3A50; border-radius: 3px; }
        .nav-btn { background: none; border: none; cursor: pointer; padding: 10px 16px; border-radius: 8px; font-family: inherit; font-size: 13px; font-weight: 600; transition: all 0.2s; color: #888; }
        .nav-btn.active { background: #1E1E2E; color: #C4A96A; }
        .nav-btn:hover:not(.active) { color: #ccc; }
        .card { background: #1A1A24; border-radius: 16px; padding: 24px; border: 1px solid #2A2A38; }
        .stat-card { background: linear-gradient(135deg, #1E1E2E, #161620); border-radius: 16px; padding: 22px; border: 1px solid #2A2A38; }
        .btn-primary { background: linear-gradient(135deg, #C4A96A, #A88B4A); color: #0F0F14; border: none; padding: 10px 20px; border-radius: 10px; cursor: pointer; font-family: inherit; font-weight: 700; font-size: 14px; transition: all 0.2s; }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 20px rgba(196,169,106,0.3); }
        .btn-ghost { background: none; border: 1px solid #3A3A50; color: #888; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-family: inherit; font-size: 13px; transition: all 0.2s; }
        .btn-ghost:hover { border-color: #C4A96A; color: #C4A96A; }
        input[type=number], input[type=text] { background: #0F0F14; border: 1px solid #3A3A50; border-radius: 8px; padding: 10px 14px; color: #E8E6E1; font-family: inherit; font-size: 14px; outline: none; width: 100%; }
        input[type=number]:focus, input[type=text]:focus { border-color: #C4A96A; }
        select { background: #0F0F14; border: 1px solid #3A3A50; border-radius: 8px; padding: 8px 12px; color: #E8E6E1; font-family: inherit; font-size: 13px; outline: none; cursor: pointer; }
        select:focus { border-color: #C4A96A; }
        .drop-zone { border: 2px dashed #3A3A50; border-radius: 16px; padding: 40px; text-align: center; cursor: pointer; transition: all 0.2s; }
        .drop-zone:hover, .drop-zone.active { border-color: #C4A96A; background: rgba(196,169,106,0.05); }
        .progress-bar { height: 8px; border-radius: 4px; background: #2A2A38; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 4px; transition: width 0.5s ease; }
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 100; padding: 20px; }
        .modal { background: #1A1A24; border-radius: 20px; padding: 30px; border: 1px solid #2A2A38; width: 100%; max-width: 400px; }
        .txn-row { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 10px; transition: background 0.15s; }
        .txn-row:hover { background: #1E1E2E; }
      `}</style>

      {/* Header */}
      <div style={{ background: "#13131C", borderBottom: "1px solid #2A2A38", padding: "0 20px" }}>
        <div style={{ maxWidth: 960, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 36, height: 36, background: "linear-gradient(135deg,#C4A96A,#A88B4A)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, color: "#0F0F14", fontWeight: 800 }}>₪</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 17 }}>תקציב חכם</div>
              <div style={{ fontSize: 11, color: "#555" }}>ניהול פיננסי אישי</div>
            </div>
          </div>
          <nav style={{ display: "flex", gap: 2 }}>
            {[["dashboard","📊 סקירה"],["transactions","💳 עסקאות"],["history","📅 היסטוריה"],["upload","📂 העלאה"]].map(([v,l]) => (
              <button key={v} className={`nav-btn${view===v?" active":""}`} onClick={() => setView(v)}>{l}</button>
            ))}
          </nav>
        </div>
      </div>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "28px 20px" }}>

        {/* Month Selector */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => { if (selectedMonth===0){setSelectedMonth(11);setSelectedYear(y=>y-1);}else setSelectedMonth(m=>m-1); }}
              style={{ background:"#1E1E2E",border:"1px solid #2A2A38",color:"#888",width:32,height:32,borderRadius:8,cursor:"pointer",fontSize:16 }}>‹</button>
            <div style={{ fontWeight:700,fontSize:18,minWidth:140,textAlign:"center" }}>{MONTHS[selectedMonth]} {selectedYear}</div>
            <button onClick={() => { if (selectedMonth===11){setSelectedMonth(0);setSelectedYear(y=>y+1);}else setSelectedMonth(m=>m+1); }}
              style={{ background:"#1E1E2E",border:"1px solid #2A2A38",color:"#888",width:32,height:32,borderRadius:8,cursor:"pointer",fontSize:16 }}>›</button>
          </div>
          <button className="btn-primary" onClick={openIncomeEdit}>✏️ עדכן הכנסות</button>
        </div>

        {/* DASHBOARD */}
        {view === "dashboard" && (
          <div>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16,marginBottom:24 }}>
              {[
                { label:"הכנסות",value:formatILS(totalIncome),sub:`משכורת + תוספות`,color:"#4ECDC4",icon:"💰" },
                { label:"הוצאות",value:formatILS(totalExpenses),sub:`${data.transactions.length} עסקאות`,color:"#FF6B6B",icon:"💳" },
                { label:"חיסכון",value:formatILS(data.savings),sub:`${totalIncome>0?Math.round(data.savings/totalIncome*100):0}% מההכנסות`,color:"#C4A96A",icon:"🏦" },
                { label:"פנוי לשימוש",value:formatILS(Math.max(freeCash,0)),sub:freeCash<0?`⚠️ חריגה של ${formatILS(-freeCash)}`:"נהדר! 🎉",color:freeCash>=0?"#4ECDC4":"#FF6B6B",icon:freeCash>=0?"✨":"🚨" },
              ].map(s=>(
                <div key={s.label} className="stat-card">
                  <div style={{fontSize:24,marginBottom:8}}>{s.icon}</div>
                  <div style={{fontSize:12,color:"#666",marginBottom:4}}>{s.label}</div>
                  <div style={{fontSize:22,fontWeight:800,color:s.color,marginBottom:4}}>{s.value}</div>
                  <div style={{fontSize:11,color:"#555"}}>{s.sub}</div>
                </div>
              ))}
            </div>
            {totalIncome > 0 && (
              <div className="card" style={{marginBottom:24}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:12}}>
                  <span style={{fontWeight:700}}>שימוש בתקציב החודשי</span>
                  <span style={{color:"#888",fontSize:14}}>{Math.round((totalExpenses+data.savings)/totalIncome*100)}% נוצל</span>
                </div>
                <div className="progress-bar" style={{height:14}}>
                  <div className="progress-fill" style={{width:`${Math.min((totalExpenses+data.savings)/totalIncome*100,100)}%`,background:`linear-gradient(90deg,#4ECDC4,${freeCash<0?"#FF6B6B":"#C4A96A"})`}} />
                </div>
                <div style={{display:"flex",gap:24,marginTop:12,fontSize:13,color:"#666"}}>
                  <span>🔴 הוצאות: {formatILS(totalExpenses)}</span>
                  <span>🟡 חיסכון: {formatILS(data.savings)}</span>
                  <span>🟢 פנוי: {formatILS(Math.max(freeCash,0))}</span>
                </div>
              </div>
            )}
            {catTotals.length > 0 ? (
              <div className="card">
                <div style={{fontWeight:700,marginBottom:20}}>הוצאות לפי קטגוריה</div>
                <div style={{display:"flex",flexDirection:"column",gap:14}}>
                  {catTotals.sort((a,b)=>b.total-a.total).map(cat=>(
                    <div key={cat.id}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:6,fontSize:14}}>
                        <span>{cat.label}</span>
                        <span style={{color:cat.color,fontWeight:700}}>{formatILS(cat.total)}</span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{width:`${cat.total/maxCat*100}%`,background:cat.color}} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="card" style={{textAlign:"center",padding:48}}>
                <div style={{fontSize:48,marginBottom:16}}>📊</div>
                <div style={{color:"#555",fontSize:15}}>אין עדיין עסקאות לחודש זה</div>
                <div style={{color:"#444",fontSize:13,marginTop:8}}>העלה קובץ אקסל מהאשראי שלך</div>
                <button className="btn-primary" style={{marginTop:20}} onClick={()=>setView("upload")}>📂 העלה עכשיו</button>
              </div>
            )}
          </div>
        )}

        {/* TRANSACTIONS */}
        {view === "transactions" && (
          <div className="card">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
              <div style={{fontWeight:700,fontSize:18}}>עסקאות — {MONTHS[selectedMonth]}</div>
              <div style={{color:"#888",fontSize:14}}>{data.transactions.length} עסקאות | {formatILS(totalExpenses)}</div>
            </div>
            {data.transactions.length === 0 ? (
              <div style={{textAlign:"center",padding:40,color:"#555"}}>
                <div style={{fontSize:40,marginBottom:12}}>💳</div>
                <div>אין עסקאות. העלה קובץ אקסל מחברת האשראי שלך.</div>
                <button className="btn-primary" style={{marginTop:16}} onClick={()=>setView("upload")}>📂 העלה קובץ</button>
              </div>
            ) : (
              <div style={{maxHeight:520,overflowY:"auto"}}>
                {data.transactions.map(t=>{
                  const cat = CATEGORIES.find(c=>c.id===t.category)||CATEGORIES[7];
                  return (
                    <div key={t.id} className="txn-row">
                      <div style={{width:36,height:36,borderRadius:10,background:cat.color+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{cat.label.split(" ")[0]}</div>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontWeight:600,fontSize:14,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{t.description}</div>
                        <div style={{fontSize:12,color:"#555"}}>{t.date}</div>
                      </div>
                      <select value={t.category} onChange={e=>updateTxnCategory(t.id,e.target.value)} style={{fontSize:12,padding:"5px 8px"}}>
                        {CATEGORIES.map(c=><option key={c.id} value={c.id}>{c.label}</option>)}
                      </select>
                      <div style={{fontWeight:700,color:"#FF6B6B",minWidth:80,textAlign:"left",flexShrink:0}}>{formatILS(Math.abs(t.amount))}</div>
                      <button onClick={()=>deleteTxn(t.id)} style={{background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:16,padding:"4px"}}>🗑</button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* HISTORY */}
        {view === "history" && (
          <div>
            {historyWithData.length > 0 && (()=>{
              const totalInc = historyWithData.reduce((s,h)=>s+h.income,0);
              const totalExp = historyWithData.reduce((s,h)=>s+h.expenses,0);
              const totalSav = historyWithData.reduce((s,h)=>s+h.savings,0);
              return (
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,marginBottom:24}}>
                  {[
                    {label:"ממוצע הכנסות חודשי",value:formatILS(Math.round(totalInc/historyWithData.length)),color:"#4ECDC4",icon:"💰"},
                    {label:"ממוצע הוצאות חודשי",value:formatILS(Math.round(totalExp/historyWithData.length)),color:"#FF6B6B",icon:"💳"},
                    {label:'סה"כ חיסכון נצבר',value:formatILS(totalSav),color:"#C4A96A",icon:"🏦"},
                  ].map(s=>(
                    <div key={s.label} className="stat-card">
                      <div style={{fontSize:22,marginBottom:6}}>{s.icon}</div>
                      <div style={{fontSize:11,color:"#666",marginBottom:4}}>{s.label}</div>
                      <div style={{fontSize:20,fontWeight:800,color:s.color}}>{s.value}</div>
                    </div>
                  ))}
                </div>
              );
            })()}
            {historyWithData.length > 0 && (
              <div className="card" style={{marginBottom:24}}>
                <div style={{fontWeight:700,marginBottom:20}}>הוצאות לפי חודש</div>
                <div style={{display:"flex",alignItems:"flex-end",gap:8,height:120}}>
                  {historyMonths.filter(h=>h.income>0||h.txCount>0).map(h=>(
                    <div key={h.key} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:6}}>
                      <div style={{fontSize:10,color:"#888",fontWeight:700}}>{formatILS(h.expenses).replace("₪","")}</div>
                      <div style={{width:"100%",height:`${Math.max(h.expenses/maxExpHistory*90,4)}px`,borderRadius:"4px 4px 0 0",background:h.free>=0?"linear-gradient(180deg,#4ECDC4,#3ABAB0)":"linear-gradient(180deg,#FF6B6B,#E05555)",cursor:"pointer"}}
                        onClick={()=>{setSelectedMonth(h.month);setSelectedYear(h.year);setView("dashboard");}} />
                      <div style={{fontSize:10,color:"#555",textAlign:"center"}}>{MONTHS[h.month].slice(0,3)}</div>
                    </div>
                  ))}
                </div>
                <div style={{fontSize:12,color:"#555",marginTop:8}}>לחצי על עמודה לצפייה בפרטי החודש</div>
              </div>
            )}
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              {historyWithData.length===0 ? (
                <div className="card" style={{textAlign:"center",padding:48}}>
                  <div style={{fontSize:48,marginBottom:16}}>📅</div>
                  <div style={{color:"#555"}}>עדיין אין נתונים היסטוריים</div>
                </div>
              ) : [...historyWithData].reverse().map(h=>(
                <div key={h.key} className="card" style={{cursor:"pointer",transition:"border-color 0.2s"}}
                  onClick={()=>{setSelectedMonth(h.month);setSelectedYear(h.year);setView("dashboard");}}
                  onMouseEnter={e=>e.currentTarget.style.borderColor="#C4A96A"}
                  onMouseLeave={e=>e.currentTarget.style.borderColor="#2A2A38"}>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
                    <div style={{fontWeight:700,fontSize:16}}>{h.label}</div>
                    <div style={{display:"flex",gap:8,alignItems:"center"}}>
                      <span style={{fontSize:12,color:"#555"}}>{h.txCount} עסקאות</span>
                      <span style={{fontSize:13,fontWeight:700,color:h.free>=0?"#4ECDC4":"#FF6B6B",background:h.free>=0?"rgba(78,205,196,0.1)":"rgba(255,107,107,0.1)",padding:"3px 10px",borderRadius:20}}>
                        {h.free>=0?`+${formatILS(h.free)} פנוי`:`${formatILS(-h.free)} חריגה`}
                      </span>
                    </div>
                  </div>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
                    {[{label:"הכנסות",value:h.income,color:"#4ECDC4"},{label:"הוצאות",value:h.expenses,color:"#FF6B6B"},{label:"חיסכון",value:h.savings,color:"#C4A96A"}].map(s=>(
                      <div key={s.label}>
                        <div style={{fontSize:11,color:"#555",marginBottom:3}}>{s.label}</div>
                        <div style={{fontWeight:700,color:s.color,fontSize:15}}>{formatILS(s.value)}</div>
                      </div>
                    ))}
                  </div>
                  {h.income>0 && <div style={{marginTop:14}}><div className="progress-bar"><div className="progress-fill" style={{width:`${Math.min((h.expenses+h.savings)/h.income*100,100)}%`,background:h.free>=0?"linear-gradient(90deg,#4ECDC4,#C4A96A)":"#FF6B6B"}} /></div></div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* UPLOAD */}
        {view === "upload" && (
          <div>
            <div className={`drop-zone${dragActive?" active":""}`}
              onDragOver={e=>{e.preventDefault();setDragActive(true);}}
              onDragLeave={()=>setDragActive(false)}
              onDrop={e=>{e.preventDefault();setDragActive(false);handleFile(e.dataTransfer.files[0]);}}
              onClick={()=>fileRef.current?.click()}
              style={{marginBottom:24}}>
              <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" style={{display:"none"}} onChange={e=>handleFile(e.target.files[0])} />
              <div style={{fontSize:52,marginBottom:16}}>📂</div>
              <div style={{fontWeight:700,fontSize:18,marginBottom:8}}>גרור קובץ Excel לכאן</div>
              <div style={{color:"#555",fontSize:14}}>או לחץ לבחירת קובץ מהמחשב</div>
              <div style={{marginTop:16,fontSize:13,color:"#444"}}>קבצי .xlsx / .xls / .csv מחברת האשראי</div>
            </div>
            {uploadMsg && (
              <div style={{background:uploadMsg.includes("✅")?"#1A2E1A":"#2E1A1A",border:`1px solid ${uploadMsg.includes("✅")?"#4ECDC4":"#FF6B6B"}`,borderRadius:12,padding:16,marginBottom:24,fontSize:15,fontWeight:600,color:uploadMsg.includes("✅")?"#4ECDC4":"#FF6B6B"}}>
                {uploadMsg}
              </div>
            )}
            <div className="card">
              <div style={{fontWeight:700,marginBottom:16}}>💡 איך זה עובד?</div>
              <div style={{color:"#666",fontSize:14,lineHeight:1.8}}>
                <div>1. היכנסי לאתר חברת האשראי שלך (ישראכרט, ויזה, מאסטרקארד)</div>
                <div>2. הורידי את פירוט העסקאות כקובץ Excel לחודש הנוכחי</div>
                <div>3. גרירי את הקובץ לאזור ההעלאה למעלה</div>
                <div>4. המערכת תסווג אוטומטית את ההוצאות לקטגוריות</div>
                <div>5. ניתן לשנות קטגוריה ידנית בכרטיסיית "עסקאות"</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Income Modal */}
      {editIncome && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setEditIncome(false)}>
          <div className="modal">
            <div style={{fontWeight:800,fontSize:20,marginBottom:24}}>✏️ עדכון הכנסות — {MONTHS[selectedMonth]}</div>
            {[{label:"💰 משכורת נטו",key:"salary"},{label:"➕ הכנסות נוספות",key:"extra"},{label:"🏦 סכום לחיסכון",key:"savings"}].map(f=>(
              <div key={f.key} style={{marginBottom:18}}>
                <label style={{fontSize:13,color:"#888",display:"block",marginBottom:8}}>{f.label}</label>
                <input type="number" placeholder="0" value={incomeForm[f.key]} onChange={e=>setIncomeForm(p=>({...p,[f.key]:e.target.value}))} />
              </div>
            ))}
            <div style={{display:"flex",gap:12,marginTop:8}}>
              <button className="btn-primary" style={{flex:1}} onClick={saveIncome}>שמור</button>
              <button className="btn-ghost" onClick={()=>setEditIncome(false)}>ביטול</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
